package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.bean.Consumer;


public class EBillDao implements IEBillDao{
	
	private EntityManager entityManager;

	public EBillDao() {
		entityManager = JPAUtil.getEntityManager();
	
	}
	
	@Override
	public List<Consumer> getAllConsumer() {
		
	TypedQuery<Consumer> q = entityManager.createNamedQuery("getAllConsumers", Consumer.class);
	List<Consumer> list =(List<Consumer>) q.getResultList();
	System.out.println("DAO"+list);
	return list;

	}

	public Consumer searchConsumer(int num) {
		
		Consumer q= entityManager.find(Consumer.class, num);
		
		return q;
	}

}
