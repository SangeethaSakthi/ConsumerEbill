package com.cg.service;

import java.util.List;

import com.cg.bean.Consumer;



public interface IEBillService {

	List getAllConsumers();

	Consumer searchConsumer(int num);

}
