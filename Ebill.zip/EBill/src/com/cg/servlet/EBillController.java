package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.Consumer;
import com.cg.service.EBillService;
import com.cg.service.IEBillService;





/**
 * Servlet implementation class EBillController
 */
@WebServlet("/EBillController")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IEBillService service;
   
    public EBillController() {
      service = new EBillService();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("action");
		System.out.println(action);
		if(action.equals("listOfConsumers")){
			List<Consumer> list= service.getAllConsumers();
			request.setAttribute("list", list );
			RequestDispatcher dispatcher = request.getRequestDispatcher("show_consumer_list.jsp");
			dispatcher.forward(request, response);	
		
		}
		else if(action.equals("searchConsumer"))
		{
			System.out.println("Inside");
			RequestDispatcher dispatcher = request.getRequestDispatcher("showConsumer.jsp");
			dispatcher.forward(request, response);	
			
		
		}
		else if(action.equals("search")){
			
		
			String n = request.getParameter("consumerNo");
			int num = Integer.parseInt(n);
			Consumer consumer =service.searchConsumer(num);
			request.setAttribute("consumer", consumer);
			RequestDispatcher dispatcher2 = request.getRequestDispatcher("display_Consumer.jsp");
			dispatcher2.forward(request, response);	
			
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
