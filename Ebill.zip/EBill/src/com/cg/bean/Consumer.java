package com.cg.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "Consumers")
@NamedQueries(@NamedQuery(name = "getAllConsumers", query = "SELECT consumer FROM Consumer consumer"))
public class Consumer implements Serializable{

	@Override
	public String toString() {
		return "Consumer [num=" + num + ", name=" + name + ", address="
				+ address + "]";
	}
	@Id
	@Column(name="CONSUMER_NUM")
	private int num;
	@Column(name="CONSUMER_NAME")
	private String name;
	@Column(name="ADDRESS")
	private String address;
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
