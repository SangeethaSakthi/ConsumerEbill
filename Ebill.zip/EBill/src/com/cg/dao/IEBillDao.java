package com.cg.dao;

import java.util.List;

import com.cg.bean.Consumer;

public interface IEBillDao {

	public List getAllConsumer() ;
	public Consumer searchConsumer(int num);
}
