package com.cg.service;

import java.util.List;

import com.cg.bean.Consumer;
import com.cg.dao.EBillDao;

public class EBillService implements IEBillService{

	EBillDao dao;
	public EBillService() {
		dao=new EBillDao();
		
	}
	
	

	@Override
	public List<Consumer> getAllConsumers() {
		return dao.getAllConsumer();
	}



	@Override
	public Consumer searchConsumer(int num) {
		return dao.searchConsumer(num);
		
	}
	
}
